<div class="meal-item">
    <div class="image-view"><img src="Meals/Images/Meal_<?php echo $meal['id']; ?>.jpg" onerror="this.src='images/meal_icon.png';"></div>
    <div class="properties">
        <h4><?php echo $meal['name']; ?></h4>
        <div><?php echo $meal['description']; ?></div>
        <div><?php echo $meal['price']; ?></div>
    </div>
</div>