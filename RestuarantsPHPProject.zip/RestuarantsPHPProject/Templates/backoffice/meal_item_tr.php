<tr>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['price']; ?></td>
    <td><?php echo $row['description']; ?></td>
    <td>
        <form method="post" action="meals.php?restaurantId=<?php echo $_GET['restaurantId']; ?>">
            <a class="btn" href="addMeal.php?restaurantId=<?php echo $_GET['restaurantId'] ?>&mealId=<?php echo $row['id']; ?>">Edit</a>
            <Button type ="submit" name="deleteMeal" class="btn btn-red">delete</Button>
            <input type="number" name="mealId" value="<?php echo $row['id']; ?>" style="display:none;">
        </form>
    </td>
</tr>